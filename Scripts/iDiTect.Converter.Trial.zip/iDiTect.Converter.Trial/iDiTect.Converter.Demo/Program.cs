﻿using iDiTect.Converter.Licensing;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;

namespace iDiTect.Converter.Demo
{
    class Program
    {
        static void Main(string[] args)
        {            
            //CsvToTxtHelper.Convert();
            //CsvToXlsxHelper.Convert();
            //DocxToHtmlHelper.Convert();
            //DocxToImageHelper.Convert();
            //DocxToPdfHelper.Convert();
            //DocxToRtfHelper.Convert();
            //DocxToTxtHelper.Convert();
            //HtmlToDocxHelper.Convert();
            //HtmlToPdfHelper.Convert();
            //HtmlToRtfHelper.Convert();
            //HtmlToTxtHelper.Convert();
            PdfToImageHelper.Convert();
            //PdfToTxtHelper.Convert();
            //RtfToDocxHelper.Convert();
            //RtfToHtmlHelper.Convert();
            //RtfToPdfHelper.Convert();
            //RtfToTxtHelper.Convert();
            //XlsxToCsvHelper.Convert();
            //XlsxToPdfHelper.Convert();
            //XlsxToTxtHelper.Replace();
        }

        
    }
}
